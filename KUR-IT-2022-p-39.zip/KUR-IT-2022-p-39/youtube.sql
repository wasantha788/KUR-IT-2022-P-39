id,uname,uemail,upwd,umobile
4,sankam,KUMARA@GMAIL.COM,678,0763457345
8,sandun,sandun@gmail.com,876,0756754437
9,wasantha,wasanthajayasinghe95@gmail.com,123,0765789467
13,saman,saman@gmail.com,123,0767895643
